package com.student.entity;

public enum Status {

	ACTIVE, INACTIVE;
}
