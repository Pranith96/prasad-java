package com.student.dto;

import lombok.Data;

@Data
public class StudentResponseDto {

	private StudentDto student;
	private AddressDto address;
}
