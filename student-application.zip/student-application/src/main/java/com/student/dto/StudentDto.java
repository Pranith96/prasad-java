package com.student.dto;

import lombok.Data;

@Data
public class StudentDto {

	private String name;
	private String mobileNumber;
	private String email;
	private String loginId;

}
